<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>404</title>
    <link rel="stylesheet" href="<?php echo $_SESSION['path'] ?>/resource/assets/css/style.css">
  </head>
  <body>
    <h1>Error 404! Page Not Found.</h1>
  </body>
</html>
