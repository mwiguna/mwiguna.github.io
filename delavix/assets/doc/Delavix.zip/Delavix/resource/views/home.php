<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Home MVC</title>
    <link rel="stylesheet" href="<?php echo $_SESSION['path'] ?>/resource/assets/css/style.css">
  </head>
  <body>
    <h1 align="center"> Welcome To Delavix! </h1> <p>The Lightest PHP Framework</p>
  </body>
</html>
