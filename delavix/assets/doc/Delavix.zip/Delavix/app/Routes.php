<?php

$route = new Route();



//---------------- Route --------------- //

$route->url("/", "home");