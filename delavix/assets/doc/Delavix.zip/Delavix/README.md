# delavix
The Lightest PHP Framework.

Delavix is a PHP Framework which design for small until medium project. Delavix has really small size and good perform. Delavix base on simple PHP Framework which using MVC Pattern and has a few good features.


###Features : 
1. MVC-base applications.
2. Query Builder.
3. Easy to use and modify, you may creating CRUD, paging, using AJAX, using CSS and Javascript Library, and others with easy way.
4. Security : Auth, CSRF Protection, PDO.
5. Small and fast.

###System Requirements 
1. PHP >= 5.6
2. PDO PHP Extension

###Installation 
1. Unzip the package.
2. Put the delavix folders into your directory / upload into your server.

###Configuration
1. Open dir /app/Core/config.php 
2. Do the configuration for your database, auth and path. 
3. Finish. 

See [Documentation](https://mwiguna.github.io/delavix)
